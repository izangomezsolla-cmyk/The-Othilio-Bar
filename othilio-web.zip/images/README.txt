Coloca tus imágenes en esta carpeta con estos nombres:

arroz-negro.jpg
solomillo.jpg
interior.jpg
wine.jpg